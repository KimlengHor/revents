var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.start = start;
var LightWire = __webpack_require__(1);

// Custom handler name used because of Sketch bug
// Reference: http://sketchplugins.com/d/708-does-not-contain-a-handler-function-named-onrun-plugin-output
function start(context) {
  LightWire(context, 'artboards');
}

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var WebUI = __webpack_require__(2);
var Parser = __webpack_require__(5);

function LightWire(context, type) {

	var self = this;

	this.context = context;
	this.type = type;

	this.start = function () {
		function start() {
			// `self.type` variable is used because there will be more menu options, not only Artboards
			var identifier = 'lightwire.' + self.type;
			var mainThread = NSThread.mainThread();
			var threadDictionary = mainThread.threadDictionary();

			if (threadDictionary[identifier]
			// `isOpened` doesn't exist after plugin update
			// while plugin thread is still running for unknown reason.
			// The same thread bug happens even after launching Cococa `Hello World` script
			&& threadDictionary[identifier].panel.hasOwnProperty('isOpened') && threadDictionary[identifier].panel.isOpened) {
				var thread = threadDictionary[identifier];
				thread.close();
			} else {
				var webUI = new WebUI(context, __webpack_require__(6), {
					identifier: identifier, // to reuse the UI
					x: 0,
					y: 0,
					width: 200,
					height: 451,
					blurredBackground: true,
					onlyShowCloseButton: true,
					title: 'Lightwire',
					hideTitleBar: false,
					shouldKeepAround: true,
					resizable: false,
					uiDelegate: {},
					handlers: {
						insert: function () {
							function insert(name, sketchFileName) {
								self.insert(name, sketchFileName);
							}

							return insert;
						}(),
						webViewLoaded: function () {
							function webViewLoaded() {
								webUI.eval('initializeWebView(\'' + self.type + '\')');
							}

							return webViewLoaded;
						}()
					}
				});
			}
		}

		return start;
	}();

	this.insert = function () {
		function insert(name, sketchFileName) {
			var sourceDoc = MSDocument['new']();

			if (sourceDoc.readFromURL_ofType_error(context.plugin.urlForResourceNamed(sketchFileName + ".sketch").path(), "com.bohemiancoding.sketch.drawing", nil)) {
				var parser = new Parser(sourceDoc);

				var obj = parser.findLayersNamed_inContainer_filterByType(name, sourceDoc.document)[0].duplicate();

				var _context = parser.getContext();
				var currentDoc = _context.document;
				var currentPage = currentDoc.currentPage();
				var addToSelectedArtboard = obj.className() != 'MSArtboardGroup';

				var scroll = currentDoc.scrollOrigin();
				var zoom = currentDoc.zoomValue();
				var windowFrameSize = currentDoc.currentContentViewController().contentDrawView().frame().size;

				var topLeftX = scroll.x / zoom * -1;
				var topLeftY = scroll.y / zoom * -1;

				var futureElementSize = obj.frame();
				var futureElementCenterX = windowFrameSize.width / 2 / zoom - futureElementSize.width() / 2;
				var futureElementCenterY = windowFrameSize.height / 2 / zoom - futureElementSize.height() / 2;

				obj.setOrigin({ x: topLeftX + futureElementCenterX, y: topLeftY + futureElementCenterY });

				if (addToSelectedArtboard) {
					var artboards = parser.getParentArtboards();

					for (var i = 0; i < artboards.length; i++) {
						var artboard = artboards[i];
						artboard.addLayers([obj]);
					}
				}

				if (!addToSelectedArtboard) {
					currentPage.addLayers([obj]);
				}

				currentPage.changeSelectionBySelectingLayers([obj]);

				currentDoc.showMessage(self.type.charAt(0).toUpperCase() + self.type.substr(1, self.type.length - 2) + ' has been added');
			}

			sourceDoc.close();
			sourceDoc = nil;
		}

		return insert;
	}();

	this.start();
}

module.exports = LightWire;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

/* globals NSUUID NSThread NSPanel NSMakeRect NSTexturedBackgroundWindowMask NSTitledWindowMask NSWindowTitleHidden NSClosableWindowMask NSColor NSWindowMiniaturizeButton NSWindowZoomButton NSFloatingWindowLevel WebView COScript NSWindowCloseButton NSFullSizeContentViewWindowMask NSVisualEffectView NSAppearance NSAppearanceNameVibrantLight NSVisualEffectBlendingModeBehindWindow NSLayoutConstraint NSLayoutRelationEqual NSLayoutAttributeLeft NSLayoutAttributeTop NSLayoutAttributeRight NSLayoutAttributeBottom NSResizableWindowMask */
var MochaJSDelegate = __webpack_require__(3);
var parseQuery = __webpack_require__(4);

var coScript = COScript.currentCOScript();

var LOCATION_CHANGED = 'webView:didChangeLocationWithinPageForFrame:';

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(subview, edge, NSLayoutRelationEqual, view, edge, 1, constant));
}
function fitSubviewToView(subview, view, constants) {
  subview.setTranslatesAutoresizingMaskIntoConstraints(false);

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0]);
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1]);
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2]);
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3]);
}

function WebUI(context, frameLocation, options) {
  options = options || {};
  var identifier = options.identifier || NSUUID.UUID().UUIDString();
  var threadDictionary = NSThread.mainThread().threadDictionary();

  var panel;
  var webView;

  function closeHandler() {
    if (options.onPanelClose) {
      var result = options.onPanelClose();
      if (result === false) {
        return;
      }
    }

    panel.isOpened = false;
    panel.close();
  }

  // if we already have a panel opened, reuse it
  if (threadDictionary[identifier]) {
    var thread = threadDictionary[identifier];

    if (typeof thread.panel.makeKeyAndOrderFront === 'function') {
      thread.panel.makeKeyAndOrderFront(null);
      thread.panel.isOpened = true;

      return thread;
    } else {
      threadDictionary.removeObjectForKey(identifier);
    }
  }

  panel = NSPanel.alloc().init();
  panel.isOpened = true;

  // Window size
  var panelWidth = options.width || 240;
  var panelHeight = options.height || 180;
  panel.setFrame_display(NSMakeRect(options.x || 0, options.y || 0, panelWidth, panelHeight), true);

  // Titlebar
  panel.setTitle(options.title || context.plugin.name());
  if (options.hideTitleBar) {
    panel.title = "";
  }

  // Hide minize and zoom buttons
  if (options.onlyShowCloseButton) {
    panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
    panel.standardWindowButton(NSWindowZoomButton).setHidden(true);
  }

  // Close window callback
  var closeButton = panel.standardWindowButton(NSWindowCloseButton);

  closeButton.setCOSJSTargetFunction(closeHandler);
  closeButton.setAction('callAction:');

  panel.setStyleMask(options.styleMask || (options.resizable ? NSTexturedBackgroundWindowMask | NSTitledWindowMask | NSResizableWindowMask | NSClosableWindowMask | NSFullSizeContentViewWindowMask : NSTexturedBackgroundWindowMask | NSTitledWindowMask | NSClosableWindowMask | NSFullSizeContentViewWindowMask));

  panel.becomeKeyWindow();
  panel.setLevel(NSFloatingWindowLevel);

  // Appearance
  var backgroundColor = options.background || NSColor.whiteColor();
  panel.setBackgroundColor(backgroundColor);
  if (options.blurredBackground) {
    var vibrancy = NSVisualEffectView.alloc().initWithFrame(NSMakeRect(0, 0, panelWidth, panelHeight));
    vibrancy.setAppearance(NSAppearance.appearanceNamed(NSAppearanceNameVibrantLight));
    vibrancy.setBlendingMode(NSVisualEffectBlendingModeBehindWindow);

    // Add it to the panel
    panel.contentView().addSubview(vibrancy);
    fitSubviewToView(vibrancy, panel.contentView(), [0, 0, 0, 0]);
  }

  if (options.shouldKeepAround !== false) {
    // Long-running script
    coScript.setShouldKeepAround(true);
  }

  // Add Web View to window
  webView = WebView.alloc().initWithFrame(NSMakeRect(0, 0, options.width || 240, (options.height || 180) - 44));

  threadDictionary[identifier] = {
    panel: panel,
    eval: webView.stringByEvaluatingJavaScriptFromString,
    webView: webView,
    close: closeHandler
  };

  if (options.frameLoadDelegate || options.handlers) {
    var handlers = options.frameLoadDelegate || {};
    if (options.handlers) {
      var lastQueryId;
      handlers[LOCATION_CHANGED] = function (webview, frame) {
        var query = webview.windowScriptObject().evaluateWebScript('window.location.hash');
        query = parseQuery(query);
        if (query.pluginAction && query.actionId && query.actionId !== lastQueryId && query.pluginAction in options.handlers) {
          lastQueryId = query.actionId;
          try {
            query.pluginArgs = JSON.parse(query.pluginArgs);
          } catch (err) {}
          options.handlers[query.pluginAction].apply(context, query.pluginArgs);
        }
      };
    }
    var frameLoadDelegate = new MochaJSDelegate(handlers);
    webView.setFrameLoadDelegate_(frameLoadDelegate.getClassInstance());
  }
  if (options.uiDelegate) {
    var uiDelegate = new MochaJSDelegate(options.uiDelegate);
    webView.setUIDelegate_(uiDelegate.getClassInstance());
  }

  if (!options.blurredBackground) {
    webView.setOpaque(true);
    webView.setBackgroundColor(backgroundColor);
  } else {
    // Prevent it from drawing a white background
    webView.setDrawsBackground(false);
  }

  // When frameLocation is a file, prefix it with the Sketch Resources path
  if (/^(?!http|localhost|www|file).*\.html?$/.test(frameLocation)) {
    frameLocation = context.plugin.urlForResourceNamed(frameLocation).path();
  }
  webView.setMainFrameURL_(frameLocation);

  panel.contentView().addSubview(webView);
  // When uncommented, move window doesn't work
  /*fitSubviewToView(webView, panel.contentView(), [
    0, options.hideTitleBar ? 0 : 24, 0, 0
  ])*/

  panel.center();
  panel.makeKeyAndOrderFront(null);

  return {
    panel: panel,
    eval: webView.stringByEvaluatingJavaScriptFromString,
    webView: webView,
    close: closeHandler
  };
}

module.exports = WebUI;

/***/ }),
/* 3 */
/***/ (function(module, exports) {

/* globals NSUUID MOClassDescription NSObject NSSelectorFromString NSClassFromString */

module.exports = function (selectorHandlerDict, superclass) {
  var uniqueClassName = 'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(uniqueClassName, superclass || NSObject)

  delegateClassDesc.registerClass()

  // Storage Handlers
  var handlers = {}

  // Define interface
  this.setHandlerForSelector = function (selectorString, func) {
    var handlerHasBeenSet = (selectorString in handlers)
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      var dynamicFunction = eval('(function (' + args.join(', ') + ') { return handlers[selectorString].apply(this, arguments); })')

      delegateClassDesc.addInstanceMethodWithSelector_function_(selector, dynamicFunction)
    }
  }

  this.removeHandlerForSelector = function (selectorString) {
    delete handlers[selectorString]
  }

  this.getHandlerForSelector = function (selectorString) {
    return handlers[selectorString]
  }

  this.getAllHandlers = function () {
    return handlers
  }

  this.getClass = function () {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function () {
    return NSClassFromString(uniqueClassName).new()
  }

  // Convenience
  if (typeof selectorHandlerDict === 'object') {
    for (var selectorString in selectorHandlerDict) {
      this.setHandlerForSelector(selectorString, selectorHandlerDict[selectorString])
    }
  }
}


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = function (query) {
  query = query.split('?')[1];
  if (!query) {
    return;
  }
  query = query.split('&').reduce(function (prev, s) {
    var res = s.split('=');
    if (res.length === 2) {
      prev[decodeURIComponent(res[0])] = decodeURIComponent(res[1]);
    }
    return prev;
  }, {});
  return query;
};

/***/ }),
/* 5 */
/***/ (function(module, exports) {

function Parser(doc) {
    var self = this;

    this.getContext = function () {
        var doc = NSDocumentController.sharedDocumentController().currentDocument();
        var initColor;

        if (MSApplicationMetadata.metadata().appVersion > 41.2) {
            var selection = doc.selectedLayers().layers();
        } else {
            var selection = doc.selectedLayers();
        }

        return {
            document: doc,
            selection: selection
        };
    };

    this.artboardForItem = function (document, item) {
        log(item.parentGroup());
        if (item.className() == 'MSArtboardGroup') {
            return item;
        } else {
            var parent = item.parentGroup();
            return self.artboardForItem(document, parent);
        } /*else if (item.container != null) {
          return self.artboardForItem(document, item.container);
          } else {
          return null;
          }*/
    };

    this.getParentArtboards = function () {
        var context = self.getContext();

        var document = context.document;
        var selection = context.selection;
        var page = document.currentPage();

        var artboardsToSelect = [];

        for (var i = 0; i < selection.length; i++) {
            var item = selection[i];
            var artboard = self.artboardForItem(document, item);
            if (artboard != null) {
                artboardsToSelect.push(artboard);
            }
        };

        return artboardsToSelect;
    };

    this.findLayersMatchingPredicate_inContainer_filterByType = function (predicate, container, layerType) {
        var scope;
        switch (layerType) {
            case MSPage:
                scope = doc.pages();
                return scope.filteredArrayUsingPredicate(predicate);
                break;

            case MSArtboardGroup:
                if (typeof container !== 'undefined' && container != nil) {
                    if (container.className == "MSPage") {
                        scope = container.artboards();
                        return scope.filteredArrayUsingPredicate(predicate);
                    }
                } else {
                    // search all pages
                    var filteredArray = NSArray.array();
                    var loopPages = doc.pages().objectEnumerator(),
                        page;
                    while (page = loopPages.nextObject()) {
                        scope = page.artboards();
                        filteredArray = filteredArray.arrayByAddingObjectsFromArray(scope.filteredArrayUsingPredicate(predicate));
                    }
                    return filteredArray;
                }
                break;

            default:
                if (typeof container !== 'undefined' && container != nil) {
                    scope = container.children();
                    return scope.filteredArrayUsingPredicate(predicate);
                } else {
                    // search all pages
                    var filteredArray = NSArray.array();
                    var loopPages = doc.pages().objectEnumerator(),
                        page;
                    while (page = loopPages.nextObject()) {
                        scope = page.children();
                        filteredArray = filteredArray.arrayByAddingObjectsFromArray(scope.filteredArrayUsingPredicate(predicate));
                    }
                    return filteredArray;
                }
        }
        return NSArray.array(); // Return an empty array if no matches were found
    };

    this.findLayersNamed_inContainer_filterByType = function (layerName, container, layerType) {
        var predicate = typeof layerType === 'undefined' || layerType == nil ? NSPredicate.predicateWithFormat("name == %@", layerName) : NSPredicate.predicateWithFormat("name == %@ && class == %@", layerName, layerType);
        return self.findLayersMatchingPredicate_inContainer_filterByType(predicate, container);
    };
}

module.exports = Parser;

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = "file://" + context.plugin.urlForResourceNamed("_webpack_resources/7afb78b5a84a45107750e4bdbbf43c81.html").path();

/***/ })
/******/ ]);
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['start'] = __skpm_run.bind(this, 'start');
that['onRun'] = __skpm_run.bind(this, 'default')
