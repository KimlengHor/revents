export function onStartup(context) {
}

export function onShutdown(context) {
  // TODO: Make sure old plugin threads are closed before/after update when Sketch fixes this bug
}
